---
rubrique: monde
titre: Personnages
sous-titre: Qui est qui, d'où on le sait, et où il en est.
description: Les personnages de la campagne d'Isidoro et de l'ancienne table de Théodoric : alliés, famille Bridgestone, Main Noire, Alcatar et ses serviteurs.
---

<p class="prose">La colonne « Sources » renvoie aux pages où le personnage apparaît. Les informations tirées des documents de la campagne de Théodoric sont un savoir de joueur : Isidoro ne les connaît pas encore. Le sélecteur <b>Point de vue</b> les masque en vue Isidoro.</p>

## La compagnie d'Isidoro {@isidoro}

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Isidoro | Prêtre cloîtré de Lathandre, 24 ans, de Derlusk. Joué par Antoine. Voir [sa fiche](isidoro.html). | À Saelmur au début de l'attaque ; environ 2 950 XP, niveau 3 imminent. | [Journal](journal.html), [aventure 2](seances/aventure-2.html) |
| Lucas « El Tiempo » | Roublard, fils d'Antonio, enfant des villes, joueur et bluffeur. Proche de Tymora, il découvre Milil à l'abbaye. Joué par François. | Avec Isidoro à Saelmur ; il a acheté l'Encensoir et une sacoche à potions. | [Journal 1](journal/partie-1.html), [aventure 2](seances/aventure-2.html) |

::: hors-jeu {@mj}
**L'autre table.** Thôn (Tonon) et David jouent sur la même chronologie. Dans l'ancienne campagne, ils incarnaient des légionnaires venus défendre Saelmur ; ils jouent désormais **Roland et Nour**. Nour vient du temple de Derlusk, comme Isidoro, qui l'a reconnue sur la route ; leur groupe a démasqué les lycanthropes de Saelmur. L'homme indécis de la proue, dans la traversée vers Ankhapur, est le personnage de Thôn.
:::

## La famille et les proches d'Isidoro {@isidoro}

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Père Théodoro | Père d'Isidoro. Ancien fouilleur de ruines néthérisiennes, devenu prêtre de Lathandre ; il a fondé avec un moine le grand temple de Derlusk. Jadis à Bridgestone avec ce moine et le père de Lucas, il a ouvert la voie de la révolte des esclaves contre Mintar. | À Derlusk. Une vision montre Isidoro le réconcilier avec un magicien. | [Journal 1](journal/partie-1.html), [aventure 2](seances/aventure-2.html#etape-5-vers-le-nord-champ-dore-et-le-comte-du-clos) |
| La mère d'Isidoro | Veut garder son fils auprès d'elle ; seize ans de désaccord poli avec le père. | À Derlusk. | [Journal 1](journal/partie-1.html), [fiche](isidoro.html) |
| Antonio | Père de Lucas, vieux compagnon de fouille du Père Théodoro ; ravitaille le temple en textes depuis vingt ans. | À Derlusk. | [Journal 1](journal/partie-1.html) |
| Lily | Serveuse d'une taverne de Derlusk, rencontrée la veille du départ. | À Derlusk. | [Journal 1](journal/partie-1.html) |
| Capitaine Tirlin | Haut capitaine au service de la famille Baltherese, protecteur du temple de Derlusk (contenu du MJ). | Inconnu. | [Fiche](isidoro.html) |
| Frère Blaise | Jeune prêtre qui a repris le scriptorium d'Ankhapur, débordé. | À Ankhapur. | [Journal 1](journal/partie-1.html) |
| Père Basile | Nommé dans la fiche comme le contact du scriptorium d'Ankhapur. Le journal dit que l'ami du père d'Isidoro y est mort l'an dernier : à vérifier. | Incertain. | [Fiche](isidoro.html) |
| Père Pascal | Disciple de Lathandre à Ankhapur, visé par un contrat d'assassinat commandité par un haut représentant de la ville. | Prévenu par Isidoro et Lucas, qui ont tué ses deux tueurs. | [Journal 1](journal/partie-1.html) |

## Rencontrés pendant l'aventure 2 {@isidoro}

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Radagar et ses génasi | Cinq génasi de feu aux cheveux roux, venus d'un village près de « l'Île de Berck » (?), sauvés des orques. Ils portent la lettre de recommandation d'Isidoro, pour s'engager dans la garde de Heaume. | Partis s'engager à Saelmur.<span data-savoir="mj"> Hors-jeu : ce sont les lycanthropes affrontés par l'autre table.</span> | [Aventure 2](seances/aventure-2.html#etape-3-l-embuscade-des-orques) |
| Tom Martino, Mickellow Beretta | Habitués du Baladin Joyeux, à Ghlinin, cités par le gérant après le vol. Le voleur avait les cheveux bruns courts et un habit bleu. | Non démasqués. | [Aventure 2](seances/aventure-2.html#etape-2-ghlinin-et-le-baladin-joyeux) |
| Le prêtre de Champ-Doré | Prêtre du temple du village (de Heaume ?), il renseigne Isidoro sur le comté et l'abbaye. | À Champ-Doré. | [Aventure 2](seances/aventure-2.html#etape-5-vers-le-nord-champ-dore-et-le-comte-du-clos) |
| Père Patricius | Prêtre de Lathandre à l'abbaye du Cœur Radieux, vieille connaissance d'Isidoro, venue du grand temple de Derlusk, un peu plus âgé. | À l'abbaye. | [Aventure 2](seances/aventure-2.html#etape-6-l-abbaye-du-coeur-radieux) |
| Frère Malachie | Grand prêtre de Tyr, intendant de l'abbaye. | À l'abbaye. | [Aventure 2](seances/aventure-2.html) |
| Sœur Aurélia | Prêtresse d'Oghma ; aide les pèlerins à préciser leurs visions avec des cartes. | À l'abbaye. | [Aventure 2](seances/aventure-2.html) |
| Rayana | Prêtresse de Deneir, joueuse de luth, une trentaine d'années, chemise de mailles, lames et luth ; pendentif en forme de harpe, repéré par Isidoro sans qu'il le reconnaisse. | A instruit Lucas (dont un pas de danse) et parlé des Ménestrels. | [Aventure 2](seances/aventure-2.html) |
| Père Gaspard | Prêtre de Tymora à l'abbaye ; perd aux cartes et s'en réjouit. | À l'abbaye. | [Aventure 2](seances/aventure-2.html) |
| Père Damino | Prêtre de Lathandre à l'hospice du camp de réfugiés de Saelmur ; a vendu le temple de la ville pour nourrir les pauvres. | À Saelmur. | [Aventure 2](seances/aventure-2.html#etape-7-depart-de-l-abbaye-et-hospice-de-saelmur) |
| Mirel, le magicien du n°6, rue des Tanneurs | Complice d'Alcatar : livrait des réfugiés (plus de 100 cadavres prévus) à Famaruth contre un livre néthérisien. A racheté toute la belladone de la ville. | <span class="etat etat--mort">Mort</span>, tué par Lucas. | [Aventure 2](seances/aventure-2.html#etape-8-saelmur-intra-muros-et-la-rue-des-tanneurs-n-6) |
| « Madame Irma » | Vieille servante de Mirel, qui leur a ouvert. | Inconnu. | [Aventure 2](seances/aventure-2.html#etape-8-saelmur-intra-muros-et-la-rue-des-tanneurs-n-6) |
| L'orc de Mirel | Garde lourdement armé, grande hache et symbole zhentarim. | <span class="etat etat--mort">Mort</span> | [Aventure 2](seances/aventure-2.html#etape-8-saelmur-intra-muros-et-la-rue-des-tanneurs-n-6) |
| Roland et Nour | Aventuriers croisés sur la route de l'abbaye ; Nour vient du temple de Derlusk. Ils ont démasqué les lycanthropes du camp. | Montés à l'abbaye. | [Aventure 2](seances/aventure-2.html#etape-7-depart-de-l-abbaye-et-hospice-de-saelmur) |
| Père El Mundo | Bibliothécaire du temple d'Oghma de Saelmur. | À Saelmur. | [Aventure 2](seances/aventure-2.html#etape-8-saelmur-intra-muros-et-la-rue-des-tanneurs-n-6) |
| Famaruth, l'elfe sauvage des égouts | Reçoit les humains livrés par le magicien et les transforme en nécrophages. Vu en vision ; nommé dans le contrat de Mirel. | <span class="etat etat--ennemi">Inconnu</span> | [Recoupements](recoupements.html) |

## La famille Bridgestone

<figure class="famille" data-savoir="theodoric" aria-labelledby="legende-famille">
<svg viewBox="0 0 1150 330" role="img" aria-label="Arbre de la famille Bridgestone">
<path class="trait" d="M80 112 V96 H560 V112"/>
<text class="role" x="320" y="90" text-anchor="middle">frères</text>
<path class="trait" d="M820 60 V112"/>
<path class="trait trait--secret" d="M365 138 H495"/>
<path class="trait" d="M625 138 H755"/>
<path class="trait" d="M430 138 V240 H360 V256"/>
<path class="trait" d="M690 138 V225"/>
<path class="trait" d="M510 225 H1070"/>
<path class="trait" d="M510 225 V256 M650 225 V256 M790 225 V256 M930 225 V256 M1070 225 V256"/>
<g><rect class="boite" x="755" y="8" width="130" height="52" rx="4"/><text class="nom" x="820" y="31" text-anchor="middle">Le vieux comte</text><text class="role" x="820" y="49" text-anchor="middle">de Bridgestone</text></g>
<g><rect class="boite" x="15" y="112" width="130" height="52" rx="4"/><text class="nom" x="80" y="135" text-anchor="middle">Comte du Clos</text><text class="role" x="80" y="153" text-anchor="middle">frère aîné d'Elrayck</text></g>
<g><rect class="boite" x="235" y="112" width="130" height="52" rx="4"/><text class="nom" x="300" y="135" text-anchor="middle">Isoline</text><text class="role" x="300" y="153" text-anchor="middle">morte avant 1355</text></g>
<g><rect class="boite" x="495" y="112" width="130" height="52" rx="4"/><text class="nom" x="560" y="135" text-anchor="middle">Elrayck</text><text class="role" x="560" y="153" text-anchor="middle">mort en 1364 ou 1365</text></g>
<g><rect class="boite" x="755" y="112" width="130" height="52" rx="4"/><text class="nom" x="820" y="135" text-anchor="middle">Aurelia</text><text class="role" x="820" y="153" text-anchor="middle">fille du vieux comte</text></g>
<g><rect class="boite boite--pj" x="295" y="256" width="130" height="58" rx="4"/><text class="nom" x="360" y="279" text-anchor="middle">Marius</text><text class="role" x="360" y="297" text-anchor="middle">né en 1348, bâtard</text></g>
<g><rect class="boite" x="445" y="256" width="130" height="58" rx="4"/><text class="nom" x="510" y="279" text-anchor="middle">Bertrand</text><text class="role" x="510" y="297" text-anchor="middle">né en 1349, tué</text></g>
<g><rect class="boite boite--traitre" x="585" y="256" width="130" height="58" rx="4"/><text class="nom" x="650" y="279" text-anchor="middle">Peter</text><text class="role" x="650" y="297" text-anchor="middle">traître, régent</text></g>
<g><rect class="boite boite--traitre" x="725" y="256" width="130" height="58" rx="4"/><text class="nom" x="790" y="279" text-anchor="middle">Jérôme</text><text class="role" x="790" y="297" text-anchor="middle">traître, régent</text></g>
<g><rect class="boite" x="865" y="256" width="130" height="58" rx="4"/><text class="nom" x="930" y="279" text-anchor="middle">Charles</text><text class="role" x="930" y="297" text-anchor="middle">enfui à Saelmur</text></g>
<g><rect class="boite boite--pj" x="1005" y="256" width="130" height="58" rx="4"/><text class="nom" x="1070" y="279" text-anchor="middle">Théodoric</text><text class="role" x="1070" y="297" text-anchor="middle">1355 – 1373</text></g>
</svg>
<figcaption id="legende-famille" class="legende-famille">Trait plein : mariage ou filiation. Pointillés : l'union secrète d'Elrayck et d'Isoline. Cadres roses : les personnages joueurs de l'ancienne table (Théodoric pour Antoine, Marius pour François). Cadres foncés : les fils qui ont livré Bridgestone à Teldorn. L'ordre de naissance de Peter, Jérôme et Charles n'est pas précisé.</figcaption>
</figure>

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Elrayck Bridgestone | Cadet noble, frère du comte du Clos ; rôdeur de Tymora contraint de feindre la foi de Torm. Porteur de Kismet, héros du Miracle de Kzelter. | <span class="etat etat--mort">Mort</span> à la chute de Bridgestone (1364 selon Jérôme, Uktar 1365 selon Teldorn). | [Testament](documents/testament-comte-elrayck.html), [plan](documents/plan-elrayck-attaque-mintar.html) | {@theodoric}
| Aurelia | Fille unique du vieux comte, épouse d'Elrayck ; élève ses fils dans la rigueur de Torm. | Inconnu. | [Testament](documents/testament-comte-elrayck.html) | {@theodoric}
| Isoline | Femme du peuple, dame de compagnie, aimée d'Elrayck ; mère de Marius. | <span class="etat etat--mort">Morte</span> avant 1355. | [Testament](documents/testament-comte-elrayck.html) | {@theodoric}
| Le comte du Clos | Seigneur du comté du Clos ; compte sur des membres de sa famille qui tiennent le pont de Bridgestone.<span data-savoir="theodoric"> Frère aîné d'Elrayck, protecteur de Théodoric et de Marius.</span><span data-savoir="mj"> Hors-jeu : l'oncle-baron de Théodoric dans l'ancienne campagne.</span> | A envoyé ses hommes contre Bridgestone<span data-savoir="theodoric"> ; selon Jérôme, se soumet à Mintar le 22 Ches 1373</span>. | [Jérôme](documents/journal-jerome-bridgestone.html), [aventure 2](seances/aventure-2.html) | {@isidoro @theodoric}
| Théodoric Bridgestone | Dernier fils d'Elrayck, paladin de Tymora, fondateur des Lames de Tymora. Joué par Antoine dans l'ancienne campagne. | <span class="etat etat--mort">Mort</span> le 15 Tarsakh 1373 en brisant la pierre de la citadelle de Mintar. | [Le sacrifice de Mintar](seances/sacrifice-de-mintar.html) | {@theodoric}
| Marius | Fils d'Elrayck et d'Isoline, formé par Vardak au maniement des deux armes ; ami puis frère de Théodoric. Joué par François. | Survivant de Mintar, enfui par la mer. | [Testament](documents/testament-comte-elrayck.html), [le sacrifice de Mintar](seances/sacrifice-de-mintar.html) | {@theodoric}
| Bertrand | Fils aîné légitime, né en 1349. | <span class="etat etat--mort">Tué</span> sur les remparts à la chute de Bridgestone. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Peter | Paladin de Torm passé à Teldorn dès 1360 ; a ouvert les portes de Bridgestone. | <span class="etat etat--ennemi">Régent</span> ; prévoit d'incendier l'abbaye du Cœur Radieux à l'aube du 26 Ches 1373. | [Jérôme](documents/journal-jerome-bridgestone.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Jérôme | Fils méthodique et rancunier ; a juré fidélité à Xvim. Tente trois fois de faire tuer Théodoric. | <span class="etat etat--ennemi">Régent</span> de Bridgestone pour Mintar. | [Son journal](documents/journal-jerome-bridgestone.html) | {@theodoric}
| Charles | Fils rebelle, en rupture avec la noblesse ; enfui à Saelmur avec une cassette d'or. | Capturé dans les égouts de Saelmur par les Bainiens, puis arraché par des morts-vivants (selon Teldorn). | [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [le sacrifice de Mintar](seances/sacrifice-de-mintar.html) | {@theodoric}
| Vardak | Maître d'armes d'Elrayck, qui a formé Marius puis Théodoric. | Inconnu. | [Testament](documents/testament-comte-elrayck.html) | {@theodoric}
| Le vieux comte de Bridgestone | Père d'Aurelia ; a financé Elrayck contre ce mariage. | Inconnu. | [Testament](documents/testament-comte-elrayck.html) | {@theodoric}

## La compagnie de Théodoric, les Lames de Tymora {@theodoric}

::: hors-jeu
Tout ce groupe appartient à l'ancienne campagne. Dans la chronologie, sa dernière mission (15 Tarsakh 1373) se déroule après l'attaque de Saelmur où se trouve Isidoro.
:::

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Bern | Roublard du commando ; a recueilli les renseignements sur Mintar et volé les documents de Teldorn. | <span class="etat etat--mort">Mort</span> : happé par l'aboleth, achevé par Kismet qui sauve le sac de documents. | [Notes de Bern](documents/notes-de-bern.html), [le sacrifice de Mintar](seances/sacrifice-de-mintar.html) |
| Ninfaya | Membre du commando. | Survivante, réfugiée à Bridgestone « sous la protection de Charles ». | [Le sacrifice de Mintar](seances/sacrifice-de-mintar.html) |
| Georborg et Lindil Fireblade | Nains d'or des Alimir, vignerons de Mintar ; ont fait entrer le commando dans leurs tonneaux. | Ont recueilli Marius dans leur barque. | [Plan d'Elrayck](documents/plan-elrayck-attaque-mintar.html), [notes de Bern](documents/notes-de-bern.html) |
| Micheline | Aubergiste de la Pinte sans Fond, près du Clos, QG des Lames de Tymora ; elle attend un enfant. | Détient Kismet et le sac de documents de Teldorn. | [Le sacrifice de Mintar](seances/sacrifice-de-mintar.html) |
| Les légionnaires | Personnages de Thôn et David dans l'ancienne campagne, venus du Chessenta défendre Saelmur. | Voir l'autre table. | [Jérôme](documents/journal-jerome-bridgestone.html) |
| Kismet | Épée intelligente chaotique bonne, la Lame du Surtaut. | À la Pinte sans Fond depuis le 15 Tarsakh 1373. | [Fiche de Kismet](documents/kismet-lame-du-surtaut.html) |

## La Main Noire et Mintar

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Teldorn Sombrespoir | Maître de Mintar, dont les combattants volants frappent autour de Saelmur.<span data-savoir="theodoric"> Vicaire de la Main Noire (Xvim, puis Baine revenu), maître de Mintar depuis 1362. Prie seul à minuit dans sa chapelle.</span> | <span data-savoir="isidoro">Tient Mintar.</span><span data-savoir="theodoric"><span class="etat etat--mort">Tué</span> le 15 Tarsakh 1373 par le commando de Théodoric.</span> | [Ses chroniques](documents/chroniques-teldorn-sombrespoir.html), [mandat](documents/mandat-trone-de-fer.html) | {@isidoro @theodoric}
| Le tyramort | Tyrannœil mort-vivant, sentinelle de Teldorn ; lentille de l'œil central fissurée. | <span class="etat etat--mort">Détruit</span> le 15 Tarsakh 1373. | [Notes de Bern](documents/notes-de-bern.html), [Jérôme](documents/journal-jerome-bridgestone.html) | {@theodoric}
| Brixen Sombrespoir | Cousin de Teldorn, tient Kzelter et les passes de montagne. | À Kzelter. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Scyllua Sombrespoir | Nièce de Teldorn, paladine déchue, Haute Capitaine de Château-Zhentil. | Dans le Nord. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Fzoul Chembryl | Élu de Baine ; maître du Zhentarim depuis la chute de Manshoon (1370). Exige le phylactère d'Alcatar. | <span class="etat etat--ennemi">À Château-Zhentil</span> ; le convoi doit lui remettre le phylactère le 11 Eleint 1373. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [Barthélemy](documents/chroniques-dreadnis-barthelemy.html) | {@theodoric}
| Père Barthélemy l'Austère | Inquisiteur de l'Ermitage du Roc Noir, au bord de l'Anauroch ; ami d'Alcatar, intermédiaire de son pacte avec Fzoul. | Au Roc Noir. | [Ses chroniques](documents/chroniques-dreadnis-barthelemy.html) | {@theodoric}
| Père Dreadnis | Inquisiteur de Baine infiltré à la Sombre Académie de Lunargent. | <span class="etat etat--mort">Mort</span>, retrouvé avec un collier en forme de harpe. | [Ses chroniques](documents/chroniques-dreadnis-barthelemy.html) | {@theodoric}
| Malekth le Blême | Archimage de la Sombre Académie de Lunargent, acquis à Alcatar. | À Lunargent. | [Dreadnis](documents/chroniques-dreadnis-barthelemy.html) | {@theodoric}
| Kaelen (de Rougemélèze) | Chef de la cellule zhentarim de Rougemélèze ; son apprenti a espionné Alcatar. À ne pas confondre avec le Kaelen de Vandor. | Inconnu. | [Jérôme](documents/journal-jerome-bridgestone.html) | {@theodoric}
| Andbar | Aubergiste de Rougemélèze sur la Longue Route, agent du Zhentarim ; correspondant de Faeltar. Jérôme écrit « Anbar ». | Inconnu. | [Vandor](documents/journal-vandor.html), [Jérôme](documents/journal-jerome-bridgestone.html) | {@theodoric}
| Capitaine Maelstrom | Pirate de Luskan, maître des contrebandiers du Lac ; son navire, le Briseur de Vagues, transporte Alcatar. | Muet sur Alcatar après Saelmur. | [Vandor](documents/journal-vandor.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Balagos | Dracosire rouge. | A brûlé Mintar à la chute du bouclier, le 15 Tarsakh 1373. | [Le sacrifice de Mintar](seances/sacrifice-de-mintar.html) | {@theodoric}

## Alcatar et les siens

| Nom | Qui | Où il en est | Sources |
| --- | --- | --- | --- |
| Alcatar | Elfe d'or<span data-savoir="theodoric"> venu d'Éternelles-Rencontres, nécromancien prodige (Intelligence 21). Devenu liche vers 1367, Élu de Velsharoon en 1368. Bâton d'onyx habité par l'âme de son corbeau. Pacte avec Talos : Saelmur en un an</span>.<span data-savoir="isidoro"> Le visage des rêves d'Isidoro ; dans sa vision, il écrase Saelmur et pourrait prendre la place de Velsharoon.</span> | <span data-savoir="isidoro"><span class="etat etat--ennemi">Ennemi</span> ; vu en vision.</span><span data-savoir="theodoric"><span class="etat etat--ennemi">En fuite</span> après Saelmur, vers Château-Zhentil puis peut-être la Vaasie (selon Teldorn).</span> | [Aventure 2](seances/aventure-2.html)<span data-savoir="theodoric">, [Dreadnis et Barthélemy](documents/chroniques-dreadnis-barthelemy.html), [Vandor](documents/journal-vandor.html)</span><span data-savoir="mj">, [recoupements](recoupements.html#les-phylacteres-d-alcatar)</span> | {@isidoro @theodoric}
| Vandor d'Hauterive | Vampire aristocrate et cambrioleur, bras armé d'Alcatar ; a préparé le sabotage de Saelmur. | <span class="etat etat--ennemi">Terré dans les égouts</span> de Saelmur après le 20 Ches 1373 ; doit regagner Lunargent si Alcatar ne revient pas sous dix jours. | [Son journal](documents/journal-vandor.html) | {@theodoric}
| Élysia | Sœur de Vandor, grande prêtresse de Velsharoon à la Loge de l'Ossement. | Gardienne du premier phylactère d'Alcatar, dans les Monts Nethéres. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Faeltar | Roublard, rival de Vandor ; espion du Zhentarim. | <span class="etat etat--mort">Exécuté</span> par Alcatar en 1371. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Arrk | Troll mercenaire d'une intelligence anormale ; a accompagné Alcatar dans la forêt de Qurth. | Vu dans les tavernes d'Innarlith. | [Vandor](documents/journal-vandor.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Malakor | Ancien maître vampire de Vandor et d'Élysia. | <span class="etat etat--mort">Détruit</span> par Alcatar et Faeltar en 1360. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Valentin, Valérie et Adrien d'Hauterive | Frère (mort), nièce et neveu de Vandor ; Valérie tient la taverne du Faucon d'Argent à Lunargent, Adrien étudie l'illusion à la Sombre Académie. | À Lunargent. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Brant | Homme de main de Vandor, serveur au Faucon d'Argent. | À Lunargent. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Kaelen (de Vandor) | Jeune homme de main de Vandor. | <span class="etat etat--mort">Mort</span> d'une flèche empoisonnée orque. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Lady Isolda | Haute aristocrate de Saelmur, vampirisée par Vandor. | Dans les égouts de Saelmur, à son service. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Mastro Corvaux | Antiquaire borgne d'Iriaebor, a vendu à Alcatar les routes vers le Grand Shaar. | À Iriaebor. | [Vandor](documents/journal-vandor.html) | {@theodoric}

## Puissances et figures lointaines

- **Dieux du côté d'Isidoro** : Lathandre, le Seigneur du Matin (qu'Isidoro tient pour Amaunator revenu), Tymora, Milil, Deneir, Oghma, Tyr, Heaume, Torm, Kelemvor.
- **Dieux de l'ennemi** : Velsharoon, dieu de la nécromancie<span data-savoir="theodoric">, dont Alcatar est l'Élu ; Talos, à qui Alcatar doit Saelmur ; Baine, revenu en 1372, et Iyachtu Xvim ; Cyric. Myrkul, mort, aurait été le premier dieu d'Alcatar selon Barthélemy</span>.
- **Grandes figures** : le prophète Alaundo, dont les écrits sont à Château-Suif ; Manshoon et Sammaster, dont les clones auraient semé la magie sauvage l'an dernier<span data-savoir="theodoric"> ; Dame Alustriel de Lunargent, qui laisse Alcatar circuler ; Elminster, Szass Tam</span>.
- **Organisations** : les Ménestrels (la harpe) ; le Zhentarim ou Réseau Noir ; le Trône de Fer ; les Magiciens Rouges de Thay ; le culte du Dragon ; l'Église de Bane<span data-savoir="theodoric"> ; la Main Noire de Baine ; la Sombre Académie de Lunargent ; la Loge de l'Ossement</span>.
