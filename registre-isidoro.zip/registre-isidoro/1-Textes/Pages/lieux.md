---
rubrique: monde
titre: Lieux et cartes
sous-titre: Le Lac de Vapeur, le comté du Clos et la citadelle de Mintar.
description: Les lieux de la campagne d'Isidoro au Lac de Vapeur, un schéma de la région, les plans de Mintar, de ses égouts et du château de Teldorn.
---

## La région, en schéma

<figure class="carte-schema" aria-labelledby="legende-schema">
<svg viewBox="0 0 900 600" role="img" aria-label="Schéma de la région du Lac de Vapeur autour de Saelmur">
<path class="eau" d="M110 372 C170 340 240 352 300 360 C360 345 420 330 470 338 C540 330 610 345 660 352 C720 345 800 360 880 395 L890 470 C820 520 760 560 700 566 C620 580 540 570 470 560 C380 556 300 548 220 520 C160 500 120 450 110 372 Z"/>
<path class="bois" d="M245 32 C290 12 360 18 380 44 C392 68 350 84 300 80 C258 78 228 56 245 32 Z"/>
<path class="bois" d="M500 540 C540 520 610 522 640 545 C650 568 600 590 545 588 C505 584 482 562 500 540 Z"/>
<path class="fleuve" d="M330 356 C322 300 342 250 330 200 C318 150 336 110 322 60"/>
<path class="route" d="M228 352 C320 335 390 330 452 330 C540 330 600 340 650 344"/>
<path class="route" d="M455 325 C455 290 458 265 460 240 C462 210 455 185 452 168 C470 150 500 135 520 120"/>
<path class="route" d="M452 168 C420 150 380 132 338 112"/>
<text class="petit" x="560" y="440" text-anchor="middle">Lac de Vapeur</text>
<text class="petit" x="300" y="62" text-anchor="middle">Bois d'Épines</text>
<text class="petit" x="570" y="560" text-anchor="middle">Forêt de Qurth</text>
<text class="petit" x="300" y="250" text-anchor="end">la Minta</text>
<circle class="point" cx="228" cy="352" r="6"/><text class="lieu lieu--grand" x="216" y="338" text-anchor="end">Mintar</text>
<circle class="point point--ici" cx="455" cy="330" r="8"/><text class="lieu lieu--grand" x="468" y="318">Saelmur</text>
<text class="petit" x="468" y="300">la séance s'arrête ici</text>
<circle class="point" cx="650" cy="344" r="6"/><text class="lieu" x="662" y="336">Ankhapur</text>
<circle class="point" cx="862" cy="398" r="5"/><text class="lieu" x="852" y="386" text-anchor="end">Innarlith</text>
<circle class="point" cx="720" cy="556" r="6"/><text class="lieu" x="732" y="578">Derlusk</text>
<circle class="point" cx="60" cy="300" r="5"/><text class="lieu" x="60" y="285" text-anchor="middle">Kzelter</text>
<circle class="point" cx="460" cy="240" r="5"/><text class="lieu" x="474" y="246">Fort Corner</text>
<circle class="point" cx="452" cy="168" r="6"/><text class="lieu" x="440" y="190" text-anchor="end">Le Clos</text>
<circle class="point" cx="520" cy="120" r="5"/><text class="lieu" x="532" y="116">abbaye du Cœur Radieux</text>
<circle class="point" cx="485" cy="150" r="4"/><text class="lieu" x="497" y="162">Champ-Doré</text>
<circle class="point" cx="333" cy="112" r="6"/><text class="lieu" x="318" y="122" text-anchor="end">Bridgestone</text>
</svg>
<figcaption id="legende-schema" class="legende-famille">Schéma de position, pas à l'échelle, établi d'après les séances et les explications d'Antoine. Pointillés : routes empruntées ou citées. Ghlinin, l'auberge du Pissenlit Bleu et la Pinte sans Fond ne sont pas placées : leur position exacte n'est pas connue. Pour la géographie réelle, voir la carte de Faerûn plus bas.</figcaption>
</figure>

## Les lieux

| Lieu | Ce qu'on en sait | Sources |
| --- | --- | --- |
| Saelmur | Cité de la rive nord, sur quatre collines : grands temples de Torm, Tyr et Heaume, université des mages-lames, Parlement des marchands, bas quartiers et docks. Remparts de 10 m, camp de réfugiés et camp militaire de Tyr. 25 000 à 30 000 habitants. Attaquée le 20 Ches 1373<span data-savoir="theodoric"> par Alcatar et Mintar, selon les documents</span>.<span data-savoir="isidoro"> Tombée dans la nuit : temples de Torm et de Heaume, université des mages et phare détruits, bibliothèque d'Oghma en flammes ; étendards zhentarim sur les remparts.</span> | [Aventure 2](seances/aventure-2.html#etape-7-depart-de-l-abbaye-et-hospice-de-saelmur), [aventure 3](seances/aventure-3.html)<span data-savoir="theodoric">, [Vandor](documents/journal-vandor.html)</span> | {@isidoro @theodoric}
| La rue des Tanneurs | Du côté des docks de Saelmur. Au n°6, l'atelier du tanneur et magicien Mirel, complice d'Alcatar, en cours de vente ; cave pleine de traces de sang et de fers, et des tonneaux de belladone laissés sur place. Une porte de pierre, dans la cave, s'est ouverte la nuit de l'attaque sur des nécrophages. La maison n'a pas brûlé : la belladone y est toujours. | [Aventure 2](seances/aventure-2.html#etape-8-saelmur-intra-muros-et-la-rue-des-tanneurs-n-6), [aventure 3](seances/aventure-3.html#etape-2-les-necrophages-de-la-cave) | {@isidoro}
| Le camp de Torm | Devant Saelmur : trois à quatre mille soldats, surtout des Heaumites sous les bannières de Torm, quartier général du maréchal Sébastien de Saint-Lun. À côté, le camp de réfugiés, environ trois mille personnes, et l'hospice du père Damino. | [Aventure 3](seances/aventure-3.html#etape-13-le-seigneur-de-trefleure-et-le-marechal) | {@isidoro}
| La baronnie de Trèfleure (?) | Baronnie voisine de Saelmur, qui élève des chevaux. | [Aventure 3](seances/aventure-3.html#etape-13-le-seigneur-de-trefleure-et-le-marechal) | {@isidoro}
| Mintar | Port de la rive nord-ouest, tenu par Teldorn Sombre-Espoir, ennemi de la région.<span data-savoir="theodoric"> Théocratie de Teldorn depuis 1362. Citadelle sur la falaise, chapelle privée, égouts gardés par un gauth, baie infestée d'aboleths. À moitié brûlée par Balagos le 15 Tarsakh 1373.</span> | [Plan d'Elrayck](documents/plan-elrayck-attaque-mintar.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [plans ci-dessous](#les-plans-de-mintar) | {@isidoro @theodoric}
| Derlusk | Ville natale d'Isidoro, sur la rive sud-est. Grand temple de Lathandre fondé par son père<span data-savoir="theodoric"> ; un espion de Teldorn y a été égorgé</span>. | [Journal 1](journal/partie-1.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@isidoro @theodoric}
| Ankhapur | Grande cité de la rive nord. Taxe d'entrée de 50 po pour les prêtres ; dockers du Trône de Fer ; scriptorium du Frère Blaise.<span data-savoir="theodoric"> Relais du convoi du phylactère le 16 Ches 1373.</span> | [Journal 1](journal/partie-1.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@isidoro @theodoric}
| Le comté du Clos | Au nord de Saelmur : plaines à blé, rocaille et vallons, sans patrouilles.<span data-savoir="theodoric mj"> Le comte est l'oncle de Théodoric.</span> | [Aventure 2](seances/aventure-2.html#etape-5-vers-le-nord-champ-dore-et-le-comte-du-clos) | {@isidoro @theodoric}
| Fort Corner | Bourg fortifié entre Saelmur et le Clos : palissade, 500 à 1 000 habitants, une cinquantaine de soldats, un temple. La garnison paie les primes. | [Aventure 2](seances/aventure-2.html#etape-4-fort-corner) | {@isidoro}
| Ghlinin | Cité du comté du même nom, à palissade et deux tours ; on y parle du nez. Auberge-casino du Baladin Joyeux. | [Aventure 2](seances/aventure-2.html#etape-2-ghlinin-et-le-baladin-joyeux) | {@isidoro}
| L'auberge du Pissenlit Bleu | Point de départ de l'aventure 2. | [Aventure 2](seances/aventure-2.html#etape-1-l-auberge-du-pissenlit-bleu) | {@isidoro}
| Champ-Doré | Hameau de fermes du comté du Clos, avec un temple qui accueille les pèlerins. | [Aventure 2](seances/aventure-2.html) | {@isidoro}
| L'abbaye du Cœur Radieux | À 1 km au nord de la route, après une auberge, sentier signalé par une stèle. Ouverte à tous, sans garnison ; de nombreux autels, aucun pour un dieu mauvais, vasques des visions, ruisseau pour se laver les pieds. Visions d'Alaundo.<span data-savoir="theodoric"> Peter Bridgestone veut l'incendier le 26 Ches 1373.</span> | [Aventure 2](seances/aventure-2.html#etape-6-l-abbaye-du-coeur-radieux), [Jérôme](documents/journal-jerome-bridgestone.html) | {@isidoro @theodoric}
| Bridgestone | Forteresse-pont au nord du comté du Clos, seul pont sur la Minta, face aux terres de Mintar ; retombée aux mains de l'ennemi. Le père d'Isidoro, un moine et le père de Lucas y ont jadis guidé la révolte des esclaves.<span data-savoir="theodoric"> Livrée à Teldorn par Peter et Jérôme.</span> | [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [Jérôme](documents/journal-jerome-bridgestone.html) | {@isidoro @theodoric}
| Le Bois d'Épines | Au-delà de Bridgestone. Une clairière d'arbres de fer aux feuilles en lames, où Elrayck a trouvé Kismet ; des œufs de dragon vert y sont peut-être restés. | [Testament](documents/testament-comte-elrayck.html) | {@theodoric}
| La Pinte sans Fond | Auberge du comté du Clos<span data-savoir="isidoro">, où Théodoric de Bridgestone fonde les Lames de Tymora ; le maréchal y envoie Isidoro et Lucas. Lucas s'est vu frapper à la porte d'une « Chope sans Fond »</span><span data-savoir="theodoric">, QG des Lames de Tymora ; Micheline la tient. Kismet et les documents de Teldorn y apparaissent le 15 Tarsakh 1373</span>. | [Le sacrifice de Mintar](seances/sacrifice-de-mintar.html), [aventure 3](seances/aventure-3.html#etape-13-le-seigneur-de-trefleure-et-le-marechal) | {@isidoro @theodoric}
| Kzelter | Cité-garnison à l'extrême est du Téthyr, entre les Monts des Flocons et la forêt de Mir. Théâtre du Miracle de Kzelter ; tenue par Brixen Sombrespoir.<span data-savoir="isidoro"> Son blason est lié à celui de Baine ; ses hommes, menés par Garrick de Bridgestone, ont pris part à l'attaque de Saelmur.</span> | [Testament](documents/testament-comte-elrayck.html), [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [aventure 3](seances/aventure-3.html#etape-8-garrick-de-bridgestone-et-les-hommes-de-kzelter) | {@isidoro @theodoric}
| La forêt de Qurth | Près de Derlusk.<span data-savoir="theodoric"> Alcatar y a mené deux expéditions et soumis des spriggans de l'ombre.</span><span data-savoir="isidoro"> Dernier lambeau du « Grand Vert » qui couvrait jadis le Shaar ; jungle humide nourrie par les brumes du Lac de Vapeur. Depuis la Campagne des Sept Brûlures (440 CV), une malédiction calishite y fait muter la faune et s'agiter les arbres dès que des humains y entrent. Abrite les ruines d'Ankharia.</span> | [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [Vandor](documents/journal-vandor.html), [carnet d'Urth](documents/carnet-urth.html) | {@isidoro @theodoric}
| Ankharia | Avant-poste néthérisien de la forêt de Qurth, fondé vers −2500 CV pour fournir ingrédients magiques et chardalyn à un grand laboratoire néthérisien du Shaar ; abandonné à la chute de Néthéril (−339). Le fleuve Scelptar le coupe en deux. Rive est : le temple d'Amaunator et son Mini-Mythallar, globe de cristal où Alcatar a lié une part de son âme en 1372 (lueur mauve et verte) ; dessous, les cryptes et la bibliothèque des elfes. Rive ouest : le temple de Shar et son puits d'ombres, déchirure vers le plan de l'Ombre, que la lumière fait reculer ; il ne rayonne plus qu'à moins d'un kilomètre. Au nord-est, l'épave d'une nef volante néthérisienne. Les elfes sauvages y vivent, gardés par la Nagahydra momifiée et une armée de nécrophages faits de cadavres d'orques. | [Carnet d'Urth](documents/carnet-urth.html), [aventure 3](seances/aventure-3.html#le-livre-netherisien-des-puits-d-ombre) | {@isidoro}
| Lhesper | Cité humaine bâtie vers 316 CV sur les rives du Lac de Vapeur, où s'étaient installés des archimages calishites ; incendiée en 440 CV par le Calimshan, lors de la Campagne des Sept Brûlures. | [Carnet d'Urth](documents/carnet-urth.html#chapitre-1-l-ambassade-de-lhesper-et-les-arts-calishites) | {@isidoro}
| Innarlith | Cité de l'est du Lac, sous l'influence secrète de Cyric. Le troll Arrk y a été vu. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html), [Vandor](documents/journal-vandor.html) | {@theodoric}
| Château-Suif | La plus grande bibliothèque de Faerûn, sur la Côte des Épées. Les écrits d'Alaundo<span data-savoir="theodoric"> et les prophéties de Baine</span> y sont conservés ; on y entre en offrant un ouvrage d'au moins 100 po.<span data-savoir="theodoric"> Alcatar y a étudié en 1364.</span> | [Aventure 2](seances/aventure-2.html), [Barthélemy](documents/chroniques-dreadnis-barthelemy.html) | {@isidoro @theodoric}
| Les repaires d'Alcatar | La Loge de l'Ossement (ancienne crypte de Thargor Barbe-de-Fer, Monts Nethéres) ; une crypte de géants nécromanciens au Grand Shaar ; une crypte néthérisienne et un second sanctuaire caché sous l'Anauroch. | [Vandor](documents/journal-vandor.html) | {@theodoric}
| Les bastions de Baine | Sous Kzelter, dans les cavernes des Pics des Crépuscules et dans une forteresse des Collines des Serpents, reliés à Mintar par des portails de l'ombre. | [Teldorn](documents/chroniques-teldorn-sombrespoir.html) | {@theodoric}
| Le Nord | Lunargent (la Sombre Académie, le Faucon d'Argent), l'Ermitage du Roc Noir, Château-Zhentil, la Citadelle du Corbeau, Rougemélèze sur la Longue Route. | [Barthélemy](documents/chroniques-dreadnis-barthelemy.html), [Vandor](documents/journal-vandor.html) | {@theodoric}

## Les plans de Mintar {@theodoric}

<p class="prose">Ces plans ont été dessinés pour l'assaut du commando de Théodoric. Cliquez sur une image pour l'ouvrir en grand.</p>

<div class="galerie">
<figure><a href="assets/img/plan-mintar.jpg"><img src="assets/img/plan-mintar.jpg" alt="Plan dessiné à la main de la ville de Mintar" loading="lazy"></a><figcaption><b>Plan de Mintar</b>Remparts, quai, caserne, temple de Xvim, gantelet noir, entrepôt, tour (« Sentharim » ?), bas quartier des esclaves, campement de l'armée, citadelle et sa chapelle, puits, étable des hippogriffes. Avertissements : patrouille volante, aboleth, plaines éclairées de nuit, « tout est à découvert sur 1 km ». Un cours d'eau de 13 m de large longe la ville.</figcaption></figure>
<figure><a href="assets/img/egouts-mintar.jpg"><img src="assets/img/egouts-mintar.jpg" alt="Plan dessiné à la main des égouts de Mintar" loading="lazy"></a><figcaption><b>Égouts de Mintar</b>Grands conduits de 3 à 4,5 m de large et 3 m de haut ; petits conduits d'environ 1 m, parfois grillagés. E : entrepôt, P : poste de garde, C : collecteur ; la légende des T est coupée sur la photo.</figcaption></figure>
<figure><a href="assets/img/chateau-teldorn.jpg"><img src="assets/img/chateau-teldorn.jpg" alt="Plan dessiné à la main du château de Teldorn" loading="lazy"></a><figcaption><b>Château de Teldorn</b>Grande cour, cour intérieure, chapelle de Teldorn, écuries des chevaux et des hippogriffes.</figcaption></figure>
</div>

## Faerûn

<figure class="figure-large">
<a href="assets/img/carte-faerun-dons-regionaux.jpg"><img src="assets/img/carte-faerun-dons-regionaux.jpg" alt="Carte des dons régionaux de Faerûn, photographiée dans un livre" loading="lazy"></a>
<figcaption>Carte des dons régionaux de Faerûn, photographiée dans un livre de la bibliothèque d'Antoine. Le Lac de Vapeur se trouve dans le sud, entre le Calimshan, le Téthyr et le Shaar.</figcaption>
</figure>
