---
savoir: isidoro
titre: Journal d'Isidoro — Aventure 3
sous-titre: La nuit où Saelmur est tombée, 20 et 21 Ches de l'an 1373 des Vaux
ordre: 3
periode: 20 – 21 Ches 1373 CV
aventure: Aventure 3
resume: Les quatre lumières, les nécrophages de la cave, les génasi de Radagar, Isola, les onze morts, les hommes de Kzelter, le rempart et la douve, le maréchal, ce que dit le livre des puits d'ombre et le mot de Kaelen.
---

**Prêtre cloîtré d'Amaunator-Lathandre, fils du Père Théodoro de Derlusk**

*Nuit du 20 au 21 Ches, an 1373 des Vaux — Troisième fragment, écrit au camp de Torm, devant une ville qui n'est plus. J'ai attendu le jour pour le commencer. Je ne suis pas certain que cela ait servi à quelque chose.*

## Les quatre lumières

J'avais interrompu le fragment précédent au seuil de l'atelier de Mirel, sous le squelette vert. Je le reprends au même endroit, car je n'en ai pas bougé tout de suite. Une partie de moi voulait courir à la bibliothèque d'Oghma. J'avais vu, dans l'eau de l'abbaye, qu'on y dresserait un bûcher avec les livres. Lucas m'a demandé, fort raisonnablement, ce que je comptais en sauver, moi qui ne connais pas ses rayonnages et ne saurais distinguer un manuscrit unique d'une chronique de comptoir. Je n'ai rien trouvé à lui répondre. C'est la première fois que mon savoir m'a paru si court.

J'ai donc fait ce que je sais faire : regarder avec méthode. La marque verte n'était pas un dessin dans le ciel, mais le croisement de quatre faisceaux de lumière, partis des quatre édifices qui couronnent les collines : le grand temple de Torm, la bibliothèque d'Oghma, l'université des mages et le temple de Heaume. Quatre maisons du savoir et du bien, retournées contre la ville qu'elles gardaient, pour y dessiner un crâne. Leur lumière était noire et verte, et elle sentait la non-vie. Quelqu'un avait préparé cela de longue date. Je crois savoir qui.

Lucas a entendu, avant moi, une porte de pierre racler le sol dans la cave de Mirel. La rue s'emplissait de familles en chemise de nuit, d'enfants qu'on portait sans savoir où aller. J'ai parlé à ces gens. Certains sont rentrés se barricader, d'autres sont partis s'habiller pour fuir. Je ne sais toujours pas lesquels j'ai sauvés.

Une voix immense est montée des docks, enflée par un sortilège : la flotte de Mintar débarquait. Lucas m'a dit qu'il était là pour me protéger avant tout, et qu'il ne ferait d'exception que pour un enfant. Il m'appelle son « guide moral ». Je n'ai pas su s'il plaisantait. Je n'ai pas eu le temps de le lui demander.

## Ce qui monta de la cave

Ils étaient six, d'abord, puis davantage : des nécrophages, qui sortaient par la porte de la cave de Mirel, dans la pièce même où nous étions passés une heure plus tôt. J'ai brisé la vitre avec mon symbole et je l'ai levé vers eux, comme je l'avais levé contre les squelettes du magicien.

La lumière est venue. Ils ont hésité, un instant. Puis ils ont continué d'avancer.

Je l'écris sans chercher à l'adoucir : mon dieu ne m'a pas abandonné, c'est moi qui ne suis pas encore assez grand pour porter ce qu'Il me donne. Les livres le disent, et je le savais : la foi d'un prêtre ne chasse que ce qu'elle peut embrasser. Le savoir, et le voir, ne sont pas la même chose.

Lucas leur a jeté l'eau bénite de l'abbaye, puis il a frappé le premier. Celui-ci l'a touché à son tour, et quelque chose a quitté Lucas, que je n'ai pas su lui rendre. Nous avons fui avec la foule.

## La garde de Heaume

Nous avons suivi des hommes en armes qui descendaient vers les docks. Derrière nous, une troupe de la garde de Heaume arrivait en renfort, et parmi eux j'ai reconnu des visages : des génasi roux. Les génasi de Radagar. Ma lettre leur avait ouvert la garde.

J'ai eu le temps d'en éprouver de la joie. Je ne la consigne que parce que je consigne tout.

En quelques souffles, ils ont changé de forme, et presque toute la troupe avec eux : une cinquantaine de rats-garous, dans notre dos. Le fer de nos hommes glissait sur eux, leurs plaies se refermaient, et il aurait fallu de l'argent que personne n'avait. Nous avons fui encore.

Je dois écrire ici une chose que je n'ai encore dite à personne. C'est ma main qui a écrit cette lettre. C'est mon nom, et celui de mon père, qui ont fait entrer ces bêtes dans la garde d'une ville assiégée. J'ai agi de bonne foi, sur la foi d'un combat partagé, d'une potion offerte, d'un récit que j'avais pris soin de rendre exact. Tout y était exact. Rien n'y était vrai. Je ne sais pas encore quelle leçon en tirer, sinon celle-ci : un document peut être parfaitement juste et pourtant servir le mensonge. Je croyais le savoir. Je viens de l'apprendre.

## Isola

Un petit squelette de rat est venu vers nous dans la rue. Mon renvoi n'a rien fait ; Lucas l'a abattu d'une flèche, et il a explosé comme un boulet, laissant un trou dans les pavés. Peu après, on a entendu exploser la ville entière, cent fois peut-être, presque ensemble. C'étaient les rats. Je n'ose imaginer ce qu'ils ont fait au milieu des foules.

Plus loin, un nécrophage marchait vers une petite fille. Nous l'avons combattu. Il m'a touché, et j'ai senti à mon tour cette chose me quitter, un peu de la lumière qu'on m'a donnée, arrachée par une main morte. Nous l'avons abattu. La petite nous a regardés et a dit : « Vous avez tué mon papa. »

C'était son père. Il ne l'était plus depuis longtemps, mais je n'ai pas trouvé les mots pour le lui dire, et je crois qu'il n'y en a pas. Elle s'appelle Isola. Elle a six ans, peut-être. Je l'ai prise dans mes bras, et je ne l'ai plus lâchée de la nuit.

C'est là que j'ai renoncé à la bibliothèque. Je l'écris tel quel. Dans l'eau de l'abbaye, ce qui m'avait le plus effrayé, ce n'était ni ma mort ni mon bras : c'était un livre qui brûle, parce qu'un livre brûlé ne revient jamais. Je l'ai écrit dans le fragment précédent, et je le pensais. Mais elle non plus ne serait pas revenue. J'ai choisi. Je ne sais pas si Oghma me le pardonnera. Je crois que Lathandre, lui, l'a compris avant moi.

## Onze

Je dois maintenant écrire ce que j'aurais voulu ne jamais avoir à écrire.

Nous avions rejoint la foule qui fuyait vers la porte de l'ouest. Des rats-garous semblaient la rabattre, comme on mène un troupeau. Un rat est arrivé entre deux fuyards. J'ai levé mon symbole. C'est le geste que j'ai appris, c'est le geste que j'ai répété cent fois dans les salles du temple, et la lumière est venue, cette fois, comme je l'avais demandée.

Les rats ont explosé tout autour de moi. Et les gens qui étaient près d'eux sont morts avec eux.

Cinq hommes. Cinq femmes. Un enfant.

Dans la rue des Tanneurs, j'ai écrit que ce n'était pas moi, mais Lui. Je n'ai pas le droit, ce soir, de me décharger sur Lui de ce qui a suivi. Le geste était le mien, et le moment, et la main. Les survivants m'ont remercié en courant, et en courant ils ont piétiné ceux qui respiraient encore.

Je me suis arrêté. Lucas m'a dit que je mettais la petite en danger, qu'il fallait penser aux vivants. Il avait raison, et je ne l'ai pas écouté. Je ne pouvais pas les laisser là, à la merci de ceux qui relèvent les morts dans cette ville. J'ai caché les yeux d'Isola contre mon épaule, j'ai rassemblé les corps, ou ce qu'il en restait, et j'ai dit sur eux la prière qui interdit aux morts de se relever. Une explosion énorme a secoué les docks au milieu de l'oraison. Je l'ai terminée. C'est la seule chose de cette nuit que je crois avoir faite entièrement bien.

J'ai regardé chacun de ces visages. Je les reconnaîtrai. Je n'ai pas demandé leurs noms : il n'y avait plus personne pour me les dire.

## La débâcle

Les restes des armées de Torm et de Heaume sont remontés des docks, une centaine d'hommes portant leurs blessés. Un soldat nous a dit, sans s'arrêter, que tout avait explosé autour d'eux, que les Tyriens s'étaient retranchés près du phare, que les Bainiens et les Zhentarim débarquaient toujours, et que la ville était perdue. Puis il m'a crié de prier, en m'appelant pauvre fou. Je l'ai fait, mais pas pour moi.

Au-dessus de leur arrière-garde, des formes ailées fondaient sur les blessés. Des vampires. Elles ne se sont pas intéressées à nous. Nous n'étions plus rien, dans cette ville : un prêtre qui grince dans son armure, un roublard, une enfant. Je m'en suis réjoui, et j'en ai eu honte.

## Les hommes de Kzelter

Nous nous sommes perdus. En voulant éviter un combat, nous nous sommes retrouvés derrière les lignes de l'ennemi, sur une petite place où des soldats se rassemblaient. J'ai reconnu leur blason : je l'avais vu dans ma vision, sans savoir le lire. C'est celui de Kzelter, que tient la famille Sombrespoir, lié à celui de Baine. Kzelter, la ville du Miracle, que l'on raconte chez nous parmi les grandes épopées du Lac de Vapeur.

Leur chef portait deux symboles. Celui des Sombrespoir. Et celui des Bridgestone.

Bridgestone. Le nom que j'ai appris enfant, celui des souterrains où mon père, un moine et le père de Lucas ont jadis rendu la liberté aux esclaves. On raconte cela chez nous comme on raconte les saints. Et voici qu'un homme de ce sang servait Baine, sur une place de Saelmur en flammes.

Il a ordonné à ses hommes d'ôter leurs armures et de se vêtir en paysans, pour sortir de la ville au milieu des réfugiés. « Alcatar nous a trahis », a-t-il dit : il aurait lâché ses explosifs sur leurs propres navires. J'ai trouvé là, au milieu de tant de malheur, une forme de justice que je n'ose pas nommer. Le serviteur de la non-vie trahit ceux qui le servent : c'est dans sa nature, et ils auraient dû le savoir. Moi, je le sais désormais.

Lucas les a jugés aguerris, bien plus que nous. Nous les avons laissés faire, et nous avons retenu leurs visages.

## Le rempart

Deux gardes zhentarim se tenaient entre le rempart et nous. J'ai caché Isola sous un tissu, contre un tonneau, en lui promettant de revenir ; il m'a fallu toute ma volonté pour m'éloigner de dix pas. Lucas et moi en sommes venus à bout. Je suis revenu la chercher. Je tenais à le noter : j'ai tenu cette promesse-là.

Du haut du rempart, j'ai regardé la ville. La bibliothèque d'Oghma commençait à brûler. À la place du temple de Torm, du temple de Heaume, de l'université et du phare, il n'y avait plus que des trous dans la nuit. Ma vision s'est accomplie jusque dans ses détails ; je l'avais consignée avec exactitude, et cela ne m'est d'aucun réconfort. J'ai senti, plus que vu, une souillure gagner les quartiers, comme une tache d'huile qui s'étend et se rejoint. J'ai eu le sentiment d'être la dernière petite lumière de cette ville. Et je m'apprêtais à la quitter.

Alors j'ai prié. J'ai demandé au Seigneur du Matin pourquoi il laissait cela arriver, s'il y avait une raison que je ne voyais pas. Mon regard est descendu vers les ruines du temple de Torm, et je l'ai vu : l'elfe d'or de mes rêves, debout sur les décombres, un bâton d'onyx à tête de corbeau à la main. Il s'est retourné. Nos regards se sont croisés l'espace d'un instant. Je ne sais pas si ce fut une grâce, ou mon propre souvenir rappelé par la prière. Je sais seulement qu'il m'a vu, et que je n'ai pas baissé les yeux.

La descente fut ce qu'elle est toujours avec moi, en moins glorieux. Isola sur le dos, j'ai manqué ma prise ; la corde m'a brûlé les mains, la paroi m'a frappé au visage, et Lucas m'a retenu d'en haut. Je lui dois donc la vie une fois de plus, et celle de la petite par la même occasion. Elle a eu si peur qu'elle s'est oubliée sur mon dos. Je ne le lui reprocherai jamais, et je défie quiconque de le faire.

Restait la douve. Je ne sais pas nager. J'ai dit à Isola de se boucher le nez, de retenir son souffle, et j'ai sauté. J'ai marché au fond, dans la vase, avec mon armure, sans respirer, tandis que les flèches crevaient la surface au-dessus de nous. Elle tapait sur mes épaules, de plus en plus fort. J'ai continué. Une flèche m'a trouvé dans le dos au moment où je sortais de l'eau. Nous nous sommes jetés dans les roseaux, et la nuit a fait le reste.

À l'abbaye, je retenais mon souffle pour que la vision dure. Cette nuit, je l'ai retenu pour qu'une enfant vive. Je préfère la seconde raison.

## Le camp

Au camp, nous avons reconnu quatre des hommes de Kzelter parmi les réfugiés, sous leurs habits de paysans. J'ai prévenu la garde et j'ai demandé qu'on les prenne vivants : un homme mort ne dit rien, et ceux-là avaient beaucoup à dire. Lucas les a suivis, ils l'ont vu, et l'un d'eux l'a jeté à terre. J'ai crié à la foule qui ils étaient. Ce sont les réfugiés eux-mêmes qui les ont retenus, ces mêmes gens qu'ils étaient venus égarer. Interrogés, ils ont donné des adresses. L'un d'eux habiterait la rue de la Biscotte. Elle n'existe pas. J'aurais pu le lui dire : j'ai consulté le cadastre.

La nuit, j'ai séché nos affaires et la petite. Elle s'est endormie contre moi. Je me suis souvenu d'un enfant qui attendait souvent un père parti au loin pour de grandes œuvres. Je ne l'ai jamais écrit. Je ne l'écrirai pas davantage ce soir. Je dirai seulement que je n'ai jamais eu de petite sœur, et qu'il me semble à présent savoir ce que c'est.

On entendait encore la ville exploser. Sur toutes les tours du rempart flottaient les étendards du Zhentarim.

## Le matin

Le père Damino nous a reçus au matin. Sa nuit avait été pire que la nôtre : plusieurs des réfugiés qu'il nourrissait sont devenus des rats-garous, et ont contaminé les autres de proche en proche, jusqu'à ce que les soldats de Torm fassent ce qu'il fallait. Il ne l'a pas décrit. Je ne le lui ai pas demandé.

Je lui ai raconté ma vision, l'elfe d'or, les égouts. Je lui ai avoué, aussi, que je doutais, et que je me sentais faible. Il m'a répondu que nous étions vivants, et que c'était là la priorité. Je l'ai écrit pour m'en souvenir, car je n'en suis pas encore convaincu.

Il n'est pas le premier à entendre parler d'un elfe derrière les morts : on lui a cité le nom d'Alcatar, et un autre groupe d'aventuriers est passé avant nous avec des renseignements sur lui. Il s'inquiète que les elfes se soient tournés contre nous. Je lui ai dit ce que je sais : les elfes d'or ont quitté ce continent il y a des milliers d'années pour une île lointaine ; ils vivent presque sans fin ; on leur doit la haute magie elfique, celle qui, jadis, a jeté la mer sur les cités humaines. Il m'a demandé si mon elfe d'or ne serait pas l'elfe sauvage des égouts. Non. Ce sont deux hommes différents, et le pire des deux n'est pas celui des égouts.

## Le maréchal

On nous a conduits au camp de Torm, où le seigneur de Trèfleure, puis le maréchal Sébastien de Saint-Lun nous ont reçus. Le maréchal est un cousin du comte. Il est tout ce que sa famille n'est pas, me dit-on : énergique, loyal, présent.

Les quatre prisonniers ont parlé. Ils venaient de Kzelter, sous les ordres de Garrick de Bridgestone, un cousin de la famille, avec mission de semer le désordre parmi les réfugiés. Ils ont été jugés, et l'on voit les gibets depuis la tente. J'avais demandé qu'on les prenne vivants. Je ne suis pas certain d'avoir le droit de m'en plaindre ; je le note.

J'ai remis le journal de Mirel, et j'ai raconté ce qu'il contenait. J'aurais pu parler de mes visions ; j'ai préféré m'en tenir aux écrits. Un écrit se vérifie. On m'a réclamé le grimoire du magicien, cet « objet souillé » ; je l'ai rendu. Mes livres seront recopiés par un prêtre du camp, et je garderai les originaux. Voilà au moins un point sur lequel tout le monde est d'accord.

La belladone de Mirel est toujours dans sa cave. C'est tout le stock de la ville, et les rats-garous ont griffé plus de réfugiés qu'on ne peut en compter. Avant la prochaine pleine lune, il faut les soigner, ou ils deviendront ce qui les a blessés. Nous y retournons ce soir.

Le maréchal tient Alcatar pour un sous-traitant du seigneur Sombrespoir. Il m'a pourtant chargé, après la belladone, de me rendre dans le comté du Clos, à la Pinte sans Fond, auprès de Théodoric de Bridgestone, le cinquième fils de la famille, qui y fonde une compagnie pour traquer Alcatar : les Lames de Tymora. Le maréchal lui fait confiance, ce qu'il ne fait pas de son frère. J'en ai été soulagé. Il n'est donc pas vrai que tout ce sang ait tourné.

Lucas, dans l'eau de l'abbaye, s'était vu frapper à la porte de la Chope sans Fond. Chope ou Pinte, je laisse aux aubergistes le soin de trancher ; le fond, lui, est le même.

Isola restera au camp, avec une femme des cuisines. Je le lui ai expliqué de mon mieux. Je lui ai proposé de prier avec moi pour son père. Elle n'a pas répondu, mais elle n'a pas lâché ma main.

Un prêtre du camp, Patrick, nous a soignés. Il m'a rendu ce que la main du mort m'avait pris. Et ce matin, en priant, j'ai senti que le Seigneur du Matin m'accordait davantage qu'hier. Je ne sais pas si je l'ai mérité. Je sais que j'en aurai besoin.

## Ce que dit le livre

J'ai pris enfin le temps de lire le livre néthérisien de Mirel. Il est écrit dans un néthérisien d'emprunt, appris et réécrit par des elfes sauvages : celui de mon père n'aurait pas toléré la moitié de ces tournures. Mais il dit des choses que je dois consigner.

Il parle de la forêt de Qurth, à quelques jours de chez moi. Les bardes prétendent que Derlusk fut un avant-poste de Néthéril ; c'est faux, ce ne fut jamais qu'une ville marchande, et les archives de notre temple le disent. L'avant-poste était dans la forêt, et le livre le confirme. Dans cette ville abandonnée, une rivière sépare un temple de Shar et un temple d'Amaunator. Amaunator. Le soleil dont procède mon dieu, face à l'ombre, à quelques jours de chez moi. Dans le temple d'Amaunator, il y a un mythallar, un globe de cristal néthérisien. Dans celui de Shar, un puits d'ombre, et depuis mille ans l'ombre gagne.

Il parle d'Alcatar. En 1365, il s'est présenté là-bas comme un prêtre de Myrkul, le dieu mort, et il a fait prier les elfes à travers lui. En 1368, Velsharoon est devenu dieu, et Alcatar son Élu ; il a alors exigé qu'on efface partout la mention de son passé, comme s'il avait toujours servi Velsharoon. Il a fait réécrire sa propre histoire. De tous ses crimes, c'est celui que je comprends le mieux, et que je pardonne le moins. Les Temps Sombres ont défiguré la mémoire des dieux ; Alcatar défigure la sienne pour qu'on oublie qui il fut.

Il a placé une part de son âme dans le mythallar de Qurth. La lumière d'Amaunator sert désormais de coffre à une liche. Je relis cette phrase, et je la laisse telle quelle.

Et le dernier chapitre, daté de Nuiteuse de l'an passé, annonce l'envoi de nécrophages à Saelmur, par le lac, entre les mains d'un contrebandier, pour « rétablir l'équilibre ». Ce livre a été écrit avant que je ne voie cette ville pour la première fois. Tout était déjà décidé quand je lavais mes pieds dans le ruisseau de l'abbaye.

Je n'ai pas tout dit du livre. Il n'était pas posé sur une étagère : il dormait dans un emballage cacheté, et sous le cachet, un mot. « Chère Mirel, ce livre a été repris aux mains de Corvus Corvath. Remets cet ouvrage à Famaruth dès que possible. » Signé : Kaelen.

J'ai relu ces trois lignes plus souvent que tout le reste du carnet. Corvus Corvath, c'est le contrebandier du dernier chapitre, celui qui a fait passer les morts par le lac. Famaruth, c'est l'elfe des égouts. Ce livre n'était donc pas le salaire de Mirel, comme je l'avais cru : Mirel n'en était que la boîte aux lettres. On l'avait arraché au contrebandier pour le rendre aux siens, et il s'est arrêté en chemin, dans mon sac. Quant à ce Kaelen, je ne connais de lui qu'une écriture et une familiarité. Quelqu'un, quelque part, croit ce livre arrivé. Le jour où il apprendra qu'il ne l'est pas, il le cherchera. J'ai brisé un cachet qui ne m'était pas adressé ; mon père m'a appris qu'on ne lit pas le courrier d'autrui. Il m'a aussi appris qu'un livre vaut mieux entre les mains de qui le comprend qu'entre celles de qui s'en sert. Je garde le second enseignement, et je m'excuse auprès du premier.

Un elfe nommé Urth, le dernier à tenir la plume, avait imaginé détruire le puits d'ombre avec de la lumière : des lentilles, des prismes, et des prières assez fortes. Alcatar s'y est opposé. Je sais désormais où je voudrais aller, un jour. Pas ce soir. Ce soir, nous rentrons dans Saelmur chercher des herbes séchées dans la cave d'un mort.

---

*Ainsi s'achève ce troisième fragment. J'y ai écrit onze morts que je n'ai pas nommés, et une enfant que je ne laisserai pas oublier son nom. Je n'en retrancherai rien.*

*— Isidoro*
