---
savoir: isidoro
titre: Journal d'Isidoro — Aventure 2
sous-titre: Du Pissenlit Bleu à la nuit du crâne vert, fin de l'hiver de l'an 1373 des Vaux
ordre: 2
periode: Fin d'hiver 1373 CV (Ches)
aventure: Aventure 2
resume: Glen et son voleur, la charge malheureuse contre les orques, Fort Corner, l'abbaye du Cœur Radieux et le visage d'Alcatar, l'hospice du père Damien et le magicien de la rue des Tanneurs.
---

**Prêtre cloîtré d'Amaunator-Lathandre, fils du Père Théodoro de Derlusk**

*Fin de l'hiver, mois de Ches, an 1373 des Vaux, que les prophéties d'Alaundo nomment l'Année de la Fureur du Dragon — Suite du premier fragment, tenue avec le même soin.*

## Le Pissenlit Bleu — Où l'on repart à pied

Nous avons quitté l'auberge du Pissenlit Bleu à pied, nos chevaux ayant péri au dernier combat. Ce n'est qu'en traversant ensuite une région d'élevage que j'ai compris la nature de cette viande étrange qu'on nous servait depuis deux jours : on mange ici le cheval comme on mange ailleurs le mouton. Je n'en dirai pas davantage.

L'aubergiste nous a exposé l'état de la guerre avec une clarté dont je lui sais gré. Teldorn Sombre-Espoir tient Mintar depuis quelques années ; ses combattants volants lancent le feu sur les environs de Saelmur ; et le pont de Bridgestone vient de retomber aux mains de l'ennemi. Une prime est offerte pour chaque agent zhentarim ou espion de Mintar : dix pièces d'or vivant, cinq mort, sur présentation de la tête et du symbole. J'y ai vu un devoir de justice. Lucas y a vu un moyen de payer le voyage. Nous sommes du moins tombés d'accord sur la conclusion, sinon sur le motif.

Il nous a aussi recommandé d'acquitter sans discuter tous les péages, les soldats étant expéditifs près du front. Conseil d'une sagesse élémentaire, que j'aurai, je le pressens, maintes occasions de rappeler en chemin.

Je me rends au Cœur Radieux parce que mon père pense que mes rêves sont peut-être un message du Seigneur du Matin. Lucas m'accompagne parce qu'il est convaincu que, sans lui, je m'attirerais des ennuis. Nous en avons parlé en chemin : je connais le monde par les livres, lui par les rues. Nous avons conclu que c'était là notre force. Je le crois sincèrement, même si les rues, jusqu'ici, ont davantage servi que les livres.

## Glen — Deux nuits au Baladin Joyeux

Nous sommes arrivés à Glen vers dix heures du soir. Le portier, un petit homme juché sur un tabouret, un caniche à ses pieds, réclamait une taxe de nuit. Je l'ai convaincu de nous ouvrir, à la seule condition de ne point faire de grabuge. Je n'en avais nullement l'intention.

Lucas a choisi notre logis : le Baladin Joyeux, une auberge tout entière vouée au jeu. Cartes, dés, et une grande roue que l'on fait tourner pour savoir qui perdra son argent. J'ai observé, et pris des notes. Deux choses m'échappent encore. La première : la roue relève du pur hasard, ce que tout le monde semble savoir, et pourtant tout le monde y joue. La seconde me déroute davantage. Le seul but avoué du jeu étant de gagner, celui qui gagne n'a, ce me semble, qu'une conduite raisonnable à tenir : se lever, empocher son gain et s'en aller. Lucas, lui, gagnait — et il est resté à la table. Il a vu sa mise tripler, puis fondre, exactement comme je l'avais prévu. J'ai longtemps cherché la logique qui pousse un gagnant à continuer de jouer ; je n'en ai trouvé aucune.

J'ai remarqué, en revanche, que les croupiers tournent toutes les deux heures, chacun avec sa propre caisse, et que celle du bar est relevée toutes les quatre heures. L'établissement est fort bien tenu. C'est bien la seule chose que j'en approuve. Avant de dormir, j'ai prié ; Lucas, lui, a bloqué la porte de notre chambre.

Au matin, il manquait deux pièces d'or à Lucas. Le gérant nous a répondu qu'il n'y avait aucune preuve. En y repensant avec méthode, je me suis souvenu d'un homme qui, pendant une main gagnante de Lucas, avait fait mine de chercher quelque chose au sol, juste derrière sa chaise : cheveux bruns et courts, vêtu de bleu — une teinte coûteuse, que l'on ne porte pas sans moyens. Avant d'agir, j'ai voulu savoir sur quel droit m'appuyer, car on ne rend pas justice sans texte : je me suis fait exposer la loi en vigueur à Glen, et je l'ai notée mot pour mot. Pour qu'un vol y soit poursuivi, il faut un flagrant délit, et des témoins autres que la victime.

J'ai donc proposé un piège. Lucas a laissé traîner une bourse entrouverte, garnie de cuivre seulement ; le véritable argent était caché. Je surveillais. Nous avions convenu d'un signal d'alerte : « deux bières ». Moi qui ne bois guère, je n'aurais jamais prononcé ces mots de moi-même ; Lucas ne pouvait donc s'y méprendre. Un employé avait été mis dans la confidence, rémunéré, précisément, de deux bières. Le procédé me semblait irréprochable.

Il a échoué. Au petit matin, la bourse était vide et je n'avais rien vu. Rien. Je ne sais toujours pas comment cela s'est fait sous mes yeux, et je m'en fais le reproche. J'ai réglé la seconde nuit.

Avant de reprendre la route, j'ai acheté une fronde, afin d'y lancer Pierre magique : un prêtre doit pouvoir frapper de loin.

## La route de l'ouest — De la charge, et de ce qu'il en coûte

En quittant Glen, Lucas, encore furieux, a pris la première sortie venue. Nous sommes partis vers l'ouest au lieu du nord, et nous ne nous en sommes aperçus que bien plus tard. Je ne lui en ai pas tenu rigueur sur le moment, ne m'en étant pas aperçu non plus.

En fin de matinée, dans une vallée, nous avons vu cinq voyageurs suivre la route en contrebas, et une dizaine d'orques s'approcher d'eux en silence. Lucas a tenté de les prévenir avec un miroir, sans succès. Sept orques ont fondu sur eux, trois sur nous. Ils portaient le symbole des Zhentarim : c'étaient des soldats de Mintar.

J'ai demandé au Seigneur du Matin de me grandir, puis de me couvrir de son bouclier, et je l'ai senti répondre. Un carreau d'arbalète, tiré de trop loin, s'est perdu. Une flèche m'a trouvé. Puis j'ai chargé. Je le rapporte sans fard : j'ai manqué mon coup, un cimeterre à deux mains m'a ouvert le flanc, et je suis tombé au premier échange. Je n'ai rien vu de la suite.

Lucas a tenu seul. Il a abattu nos adversaires, puis il est parti aider les voyageurs. Il a tenté de me faire boire une potion que je portais sur moi ; elle n'a pas suffi. C'est celle qu'a offerte le chef des voyageurs, un certain Pierrot, qui m'a rendu le souffle. Je dois donc la vie à deux hommes, ce jour-là, et j'entends ne pas l'oublier. Pierrot et les siens sont cinq génasi roux, descendants de génies, un peu balourds et fort reconnaissants, venus s'engager comme gardes à Saelmur.

J'ai rédigé le soir même un récit minutieux du combat, car un fait d'armes mal consigné devient vite une légende, et une légende n'est qu'un mensonge qui a bien vieilli. Lucas s'est attribué quatre orques. Pierrot a rectifié : trois tués, et deux autres aidés. J'ai inscrit trois et deux.

Leçon retenue : la charge n'est pas ma vocation.

Le soir, à l'auberge, Lucas a fait rire la salle par un petit spectacle. J'ai appris de mon côté que la garnison de Fort Corner payait les primes. Nous avions quatre têtes, dont celle du chef, et quatre symboles zhentarim. Justice serait faite, et dûment payée.

## Fort Corner — Du nom de mon père, et d'une querelle

La garnison nous a versé ce qui était dû pour les têtes. Au marché, nous avons vendu l'équipement des orques. J'ai voulu expliquer au marchand la loi de l'offre et de la demande, qui gouverne pourtant son métier ; il m'a regardé comme on regarde un enfant qui récite. Je maintiens que l'explication était juste.

Le lendemain matin, devant les voyageurs, j'ai raconté l'histoire de Mintar, du sultanat jusqu'à la cité maléfique de Teldorn. Les mots me sont venus comme sur le bateau, avec cette aisance que je n'attribue pas à mon seul mérite. On m'a écouté jusqu'au bout.

On m'a appris, à cette occasion, que le nom de mon père et le symbole que je porte m'ouvriront les temples de toute la région : on m'y accueillera, on m'y logera, on m'y écoutera. Je ne l'ai pas appris, à proprement parler. Je le savais. Le grand temple de Lathandre du Lac de Vapeur est celui de Derlusk ; c'est mon père et un moine qui l'ont fondé, et depuis plus de vingt ans ils y forment les missionnaires que l'on envoie partout. Ce sont des faits. Il est donc naturel qu'on les connaisse, et naturel qu'on en tienne compte. On m'a précisé que je serai écouté, mais pas forcément obéi. Cela aussi est dans l'ordre des choses, du moins pour l'instant.

J'ai rédigé pour Pierrot et les siens une lettre de recommandation, adressée aux confrères de Lathandre envoyés à Saelmur pour y fonder un temple, la ville n'en ayant pas de grand. Ces génasi nous ont prêté main-forte au combat ; il est juste qu'on le sache là où ils vont. J'y ai joint un modeste don, sans chercher de reconnaissance, et je leur ai confié la lettre, puisqu'ils partaient pour Saelmur.

Nous avons acheté nos laissez-passer : dix pièces d'or chacun jusqu'au Cœur Radieux. Le document permet de filtrer les voyageurs recherchés ; c'est un impôt légitime. Lucas, à qui je l'ai fait valoir, n'y a vu que dix pièces d'or de moins.

Au départ, Lucas a emboîté le pas aux génasi, vers le sud. Je lui ai fait remarquer que la carte indiquait une route vers le nord, un peu plus loin. Le ton est monté. Il soutenait que j'inventais cette route ; j'ai sans doute été sec, plus sec qu'il ne sied entre amis. Puis Lucas a reconnu qu'il s'était trompé, et s'est excusé d'avoir été trop dur. J'ai reconnu ma part à mon tour : j'avais raison sur le fond, tort sur la forme, et je l'avais blessé. Nous sommes convenus que la faute était partagée — ce qui, si l'on compte exactement, est une manière charitable de compter. Lathandre n'avait sans doute pas l'œil tourné vers nous ce jour-là. J'espère retrouver ses faveurs.

Lucas a ajouté que, sans son erreur de route en quittant Glen, je n'aurais peut-être pas été blessé. Je l'ai pris pour une excuse, et je crois que c'en était une.

## Vers le nord — Champ-Doré

Une patrouille de cavaliers a contrôlé nos papiers ; ils étaient en ordre, comme il se doit. Nous avons croisé de petites troupes qui descendaient vers Saelmur, au sud, où l'on rassemble l'arrière-ban. Lucas en a tiré une méthode d'orientation : puisque tous les soldats descendent vers Saelmur, il suffit de marcher à contre-courant pour être assuré d'aller au nord. Je lui ai fait observer que la méthode a ses limites : le jour où une troupe viendra de l'est, la remonter nous mènera droit vers l'est, et plus du tout vers le nord. Il n'a pas répondu, ce que je prends pour un acquiescement.

Le comté du Clos n'est que plaines retournées pour l'hiver, rocaille et collines. Pas une patrouille, et personne pour nous demander nos laissez-passer, qui nous avaient pourtant coûté dix pièces d'or. Je le relève sans amertume.

Champ-Doré n'a pas d'auberge : quelques fermes et un temple. Lucas a payé une place dans une grange, sur la paille au-dessus des cochons, et a refusé de me suivre au motif qu'« il y fait chaud ». J'ai demandé l'hospitalité au temple, qui accueille les pèlerins, et l'on m'a donné une cellule.

Le prêtre m'a appris que le comte du Clos a envoyé tous ses hommes valides contre ce qui pourrait arriver par Bridgestone, et qu'il compte sur des membres de sa famille qui tiennent le pont. Reste à savoir, m'a-t-il dit, « si le sang prévaudra sur la foi ». Il était mal à l'aise. Moi, ce nom de Bridgestone, je le connais depuis l'enfance : c'est là que mon père, un moine et le père de Lucas ont trouvé jadis le chemin des souterrains où l'on tenait les esclaves, et qu'ils y ont fait naître la révolte contre les forces de Mintar. On raconte cela chez nous comme on raconte les saints.

Il m'a dit aussi qu'ici, hors du Lac de Vapeur, seul notre culte de Derlusk prêche Lathandre. Je serai donc souvent seul dans mon combat contre l'injustice. Je l'ai écrit, et je le relis : cela ne me fait pas peur, mais cela me rend grave.

Il m'a enfin décrit l'abbaye et ceux qui la gardent : le frère Malachie, grand prêtre de Tyr, qui en est l'intendant ; la sœur Aurélia, d'Oghma, qui aide les pèlerins à lire leurs visions ; et le frère Patricius, de Lathandre — Patricius, mon ami d'enfance. J'ai recopié sa carte, qui est fort belle.

Au matin, j'ai trouvé Lucas en train de se laver au savon dans l'abreuvoir des cochons. Il a ensuite trouvé la route sans la moindre hésitation. Je rapporte les deux faits sans prétendre qu'ils soient liés.

## L'abbaye du Cœur Radieux — À la maison

À l'entrée, un ruisseau aménagé d'un banc de pierre sert à se laver les pieds, comme dans nos monastères. Je l'ai fait, et j'ai montré à Lucas comment le faire correctement. On laisse ensuite ses chaussures dans un meuble à rideaux et l'on prend des sandales propres ; les sols sont de marbre. L'abbaye abrite une multitude d'autels, petits pour les dieux mineurs, véritables temples pour les grands, et aucun pour les dieux du mal. Il y règne un calme profond.

Lucas a trouvé un autel de Milil, le dieu de la poésie et du chant, et s'est mis en tête de l'honorer par un extrait de théâtre. C'était maladroit. Les gestes ne suivaient pas les paroles, ce qui est pourtant l'essentiel. Je me suis retenu de le corriger, et je tiens à ce qu'on sache que cela m'a coûté un véritable effort de volonté. J'ai résolu, à la place, de lui trouver quelqu'un pour l'instruire.

Puis je suis entré au temple de Lathandre. L'encens. Les bougies, allumées dans le bon ordre. Le livre, posé exactement à sa place. Tout y était juste. Pour la première fois depuis Derlusk, j'étais à la maison. J'ai pensé à ma mère, et j'ai pleuré un peu, ce que je consigne parce que je consigne tout. J'ai remercié le Seigneur du Matin et je suis entré en prière.

Au bout d'un moment, quelqu'un s'est agenouillé près de moi et s'est joint à ma prière, sans un mot. Je n'ai levé les yeux qu'à la fin de l'oraison : c'était Patricius. Nous nous sommes alors retrouvés comme on se retrouve après dix ans d'absence ; il a quitté Derlusk il y a une dizaine d'années, et tient depuis peu ce temple. Je lui ai confié mes rêves. Il m'a conseillé de suivre l'office du lendemain avant de regarder dans les vasques, et il m'a prévenu : les vasques montrent plusieurs visages de l'avenir, et les dieux nous laissent notre libre arbitre. Lui-même y a souvent vu « la mort venue du ciel ». Il ne m'a pas dit ce que cela signifiait. Je crois qu'il ne le sait pas.

C'est ici que le prophète Alaundo eut ses visions, il y a des milliers d'années. Il annonça un événement pour chaque année, et tous se sont produits ; c'est lui qui nomme les années. Ses écrits reposent à Château-Suif, sur la Côte des Épées, la plus grande bibliothèque de Faerûn, où l'on n'entre qu'en offrant un ouvrage d'au moins cent pièces d'or. Je m'y rendrai un jour. L'abbaye, elle, n'a pas de vraie bibliothèque, ce que j'ai trouvé difficile à comprendre ; Patricius m'a recommandé celle du temple d'Oghma, à Saelmur.

J'ai trouvé pour Lucas une instructrice : Rayana, une habituée de l'autel de Deneir, un luth dans le dos, mais aussi une chemise de mailles et des lames, et une démarche d'une grâce peu commune. Sous sa chemise, j'ai aperçu un pendentif en forme de harpe. Je ne l'ai pas reconnu. Il me coûte de l'écrire, bien plus que l'effort de volonté de tout à l'heure : un symbole que je ne sais pas lire.

Elle a repris lentement le passage de Lucas, en lui montrant les gestes et les intonations. Il l'a rejoué ; elle a applaudi. Lucas en a été transporté. Il a ensuite tenté de la charmer. Elle a souri, avec bonté, et la chose en est restée là.

Je me suis levé à sept heures. Le petit-déjeuner était exactement celui de chez nous. Lucas, lui, rentrait à peine : il m'a appris qu'il avait passé la nuit au temple de Tymora, où l'on joue aux cartes, et qu'il en était sorti gagnant — moi, je dormais depuis longtemps. Le prêtre, le père Gaspard, perdait à chaque main et s'en réjouissait chaque fois. Je renonce à comprendre. Lucas rapportait aussi une forte gueule de bois ; j'ai demandé pour lui la clémence du Seigneur du Matin, qui a bien voulu l'accorder, même à un pécheur de cette espèce. Je me suis gardé de tout commentaire, ce qui mérite d'être relevé.

Après le repas, j'ai suivi l'office, puis, à dix heures et demie, Patricius m'a conduit aux vasques.

## Ce que j'ai vu dans l'eau

On m'avait dit que plus l'on retient son souffle, plus la vision dure. Je l'ai retenu longtemps.

::: vision
J'ai enfin vu clairement le visage de mes rêves. Un elfe d'or, des temps anciens, aux yeux glacés. Il s'appelle Alcatar. Je le sais désormais comme on sait son propre nom.

J'ai vu sa main se refermer sur une grande cité, au sud de l'abbaye. Des nécrophages et des vampires, par milliers, jaillissaient des égouts comme des rats et se jetaient sur les gens, la nuit. J'ai vu, dans un atelier sombre, Alcatar serrer la main d'un magicien humain, et ce magicien endormir des vivants pour les livrer, dans les égouts, à un elfe sauvage qui en faisait des morts.

J'ai vu les grands temples de Torm et de Heaume sauter, et la bibliothèque d'Oghma brûler. J'ai vu Alcatar marcher sur les ruines du temple de Torm, lever la main, et tracer dans le ciel une marque verte ; alors des milliers d'hommes de Mintar débarquaient par le lac.

Je me suis vu mourir une vingtaine de fois. Je me suis vu perdre un bras, tandis que Lucas, dans ces mêmes avenirs, restait sain et sauf. J'ai vu une tombe où l'on avait écrit « le héros ». Je me suis vu, parfois, sombrer dans la perdition, devenir moi-même une chose sans souffle, et perdre mon âme.

Mais j'ai vu aussi d'autres choses. Une falaise, à l'ouest de Mintar, que je descendais en rappel avec quelques compagnons pour donner un signal. Une aubergiste, des livres sur son comptoir, en grande discussion avec moi. Mon père, dans une tour isolée, face à un magicien, et les deux hommes finissant par se serrer la main — grâce à moi. Et moi, un grand marteau à la main, poursuivant Alcatar dans un combat qui dépasse tout ce que j'ai jamais lu, avec Lucas et d'autres à mes côtés, et dans ce combat, une harpe. Dans certains de ces futurs, nous le tuons. Dans d'autres, nous échouons, et il prend la place de Velsharoon. Et je me suis vu, après la liche, avoir des enfants.
:::

Je ressors de l'eau avec une certitude et une crainte. La certitude : ma tâche est peut-être d'empêcher la naissance d'un dieu du mal. La crainte, je l'avoue, n'est pas celle qu'on attendrait. Ce n'est pas ma mort qui me hante, ni mon bras. C'est la bibliothèque en flammes. Les gens, avec le temps, se relèvent et ont des enfants. Les livres, non. Un livre brûlé ne revient jamais.

Lucas a regardé lui aussi, en début d'après-midi. Il n'a pas su retenir son souffle et n'a vu que des éclairs : un panneau, « rue des Tanneurs, n°6 », une porte gravée de runes, un magicien, des squelettes ; une auberge nommée la Chope sans Fond ; et un sentier caché dans des collines, loin à l'ouest. Il a failli s'étouffer. Il en est ressorti troublé, et je ne l'avais jamais vu troublé.

## Le départ de l'abbaye

Nous avons mis nos visions en commun. La rue des Tanneurs, un magicien, des squelettes : nous avions vu la même chose. Lucas m'a avoué qu'il craint les morts-vivants, et m'a rappelé, non sans raison, que j'étais tombé devant de simples orques. Je lui ai répondu ce que je crois : c'est quand les gens de bien ignorent le mal que le mal grandit. Il a parlé de destinée. Je préfère parler de devoir. Nous sommes partis tout de même dans la même direction.

Avant notre départ, Lucas a décrit à Rayana la harpe qu'il avait vue dans l'eau — la même que celle de son pendentif, la même que celle de ma vision. Elle lui a expliqué qu'elle est le symbole de sociétés qui luttent contre le mal, que l'on appelle dans le Nord les Ménestrels, et qu'il y en a près de Mintar comme à Saelmur. Elle a conseillé à Lucas l'eau bénite plutôt que la rapière contre les morts. La joueuse de luth cachait donc d'autres talents. Voilà qui explique la démarche.

Patricius nous a donné une dizaine de fioles d'eau bénite, faites avec l'eau de l'abbaye. Lucas a aussitôt acheté une morgenstern dont la tête creuse reçoit une fiole, qui éclabousse la cible à chaque coup. On l'appelle l'Encensoir. Lucas l'appelle « le petit martinet ». Je m'abstiendrai de juger un objet qui fait un usage aussi singulier de l'eau consacrée, pourvu qu'il serve le bien.

Puis nous sommes descendus plein sud. Il ne me restait que trois rations, que je purifiais chaque matin par une prière. On n'est jamais trop prudent.

## Saelmur — L'hospice du père Damien

Je l'ai reconnue avant d'y entrer. Quatre collines étagées depuis le lac ; les grands temples de Torm et de Heaume sur les hauteurs ; des remparts de pierre neufs, hérissés de tours ; au-dehors, un immense camp de réfugiés, et le camp militaire de Tyr, carré comme une page bien réglée. Pas un navire ne bougeait sur le lac. C'était la ville de ma vision. Je l'écris calmement, mais je ne l'étais pas.

L'hospice de Lathandre se trouve au milieu du bidonville. Une longue file attendait la soupe. Le père Damien et deux aides distribuaient ce qu'ils pouvaient. Nous avons donné nos rations, celles de Lucas et les miennes réunies, douze en tout, et nous avons servi les repas jusqu'à dix heures du soir.

Le père Damien m'a appris qu'il avait vendu le temple de Lathandre de la ville, et tous ses biens, pour nourrir les pauvres. Je dois écrire ici ce que je n'ai pas dit devant lui. J'en ai été choqué. Un temple est une maison de mon dieu, et l'on ne vend pas une maison de son dieu comme on vend un chariot. Puis j'ai regardé la file. Et la charité passe avant les pierres, si belles soient-elles. Je ne suis pas certain d'avoir encore la force d'en faire autant.

Il m'a parlé des pirates qui bloquent le lac, des mages de Mintar sur leurs hippogriffes qui harcèlent les convois, des gens qui disparaissent sans même que leurs corps arrivent au cimetière de Kelemvor, et des maladies qui vont plus vite que les soins : une trentaine de prêtres pour trois cents lits. Une femme venue de notre temple de Derlusk a découvert que des lycanthropes répandaient la fièvre. Et la belladone, qui guérit la lycanthropie, manque partout : un magicien a racheté tout le stock de la ville. Je l'ai averti, en retour, de ce que j'avais vu : des morts, en hordes, dans ses rues.

Le Seigneur du Matin a bien voulu, par mes mains, guérir autant de malades que je l'en ai prié, jusqu'à ce que je n'aie plus rien à offrir. Un malade m'a craché son sang au visage, et la fièvre m'a pris presque aussitôt ; mes forces m'ont quitté. Un confrère m'a guéri sur-le-champ. Je lui en suis reconnaissant, et pourtant je regrette ce soin : il aurait pu servir à l'un de ceux qui attendaient dehors. Désormais : un foulard, et de la distance.

Lucas, pendant ce temps, a fait ce qu'il fait le mieux : il a écouté le camp. Quelques jours plus tôt, cinq hommes portant des écussons de milice cherchaient la bagarre avec les réfugiés ; c'étaient des lycanthropes. Un groupe d'aventuriers les a démasqués : trois sont morts, deux ont fui. Parmi ces aventuriers se trouvait une moniale de notre monastère de Derlusk — la femme dont parlait le père Damien. Je ne la connais pas. Mais elle vient de notre grand temple, élevé à la gloire de Lathandre-Amaunator, et c'est lui qui, même ici, a vu clair le premier. J'en tire une fierté que je ne chercherai pas à cacher. Nous avions croisé ce groupe sur la route du nord sans nous y attarder. Je le regrette.

## La rue des Tanneurs

Saelmur vit sous la loi martiale. Les habitants se méfient des réfugiés, et les génasi y sont mal vus ; j'ai pensé à Pierrot. On parle aussi d'une guerre de l'ombre entre familles marchandes depuis qu'on a retrouvé, pendu à Derlusk avec son équipage, l'héritier d'une grande maison. Derlusk. Je l'ai noté.

Au temple d'Oghma, les archives sont tenues avec un soin que j'ai trouvé admirable. Pour deux pièces d'or, le cadastre nous a désigné le n°6 de la rue des Tanneurs : une maison en cours de vente, dont le vendeur, un magicien, a déjà touché l'argent mais occupe encore les lieux. Il partait. Nous étions donc à temps, mais de peu.

J'y ai appris ce que Rayana ne nous avait dit qu'à moitié : les Ménestrels combattent les Zhentarim, le Trône de Fer, les Magiciens Rouges, le culte du Dragon et l'Église de Bane, et ils aident discrètement ceux qui servent le bien. On y prie surtout Mystra, Deneir et Tymora. Le temple a aussi identifié les deux potions que Lucas avait rapportées de notre précédente aventure : un poison mortel. Lucas les a cédées au temple, qui a retenu le prix de l'identification sur leur valeur. Un tel poison n'a rien à faire dans nos sacs ; je le préfère entre des mains sûres.

Puis j'ai étudié les liches jusqu'à la fermeture, à six heures du soir. L'âme d'une liche est enfermée dans un phylactère. Et il existe, au-delà de la liche, la demi-liche : un simple crâne, presque divin, capable d'emprisonner les âmes. Je crains qu'Alcatar n'y aspire. Je crains même qu'il n'aspire plus haut encore.

Lucas, déguisé en mendiant, a surveillé la maison jusqu'à ce que tout s'y éteigne, vers huit heures. Restait une difficulté, qui m'a tenu éveillé : avions-nous le droit d'entrer chez un homme sur la seule foi d'une vision ? Je n'en étais pas certain. Nous avons donc choisi de frapper à la porte, de nous présenter comme des messagers de l'elfe, et de ne porter la main sur lui qu'une fois sa culpabilité établie.

Une vieille servante nous a ouvert et nous a menés à son bureau. J'ai reconnu l'homme au premier regard : c'était celui de l'atelier, celui qui serrait la main d'Alcatar. Je n'avais plus de doute. Je lui ai tendu un papier roulé, « de la part d'Alcatar », et j'ai demandé au Seigneur du Matin de me grandir.

La suite fut moins ordonnée que je ne l'aurais souhaité. Lucas a frappé l'encrier. J'ai sauté par-dessus le bureau et j'ai manqué ma prise. Le magicien a appelé à l'aide. Lucas l'a blessé ; je l'ai plaqué au sol, une main sur sa bouche pour lui ôter la parole, mon poids sur ses bras pour lui interdire le moindre geste — car un magicien privé de voix et de mains n'est plus qu'un homme. Il s'en est pourtant dégagé assez pour prononcer un mot en draconique, et quatre squelettes sont sortis des armoires.

J'ai libéré une main et j'ai levé le symbole de Lathandre. Ce rite, je le connaissais par cœur pour l'avoir étudié cent fois ; je ne l'avais jamais accompli pour de bon. Les quatre squelettes ont éclaté. Qu'on ne s'y trompe pas : ce n'était pas moi, c'était Lui, et je n'ai jamais senti sa présence aussi près.

La servante est revenue changée en une brute massive, une grande hache à la main et le symbole zhentarim sur la poitrine. Lucas a abattu le magicien ; nous sommes venus à bout d'elle ensemble.

Dans son bureau, il y avait des notes. Des comptes. Le magicien embauchait des réfugiés, puis les livrait dans les égouts, et il les comptait : une cinquantaine déjà. Un contrat le liait à Alcatar : des vivants, en échange d'un livre néthérisien sur les puits d'ombre, ces lieux qui aveuglent les sorts de scrutation. Je lis le néthérisien. J'ai gardé ce livre, ainsi que ceux qu'il possédait sur les gobelinoïdes. On ne laisse pas des livres derrière soi.

À la cave, il y avait des fers, du sang, et ce qui restait de ce qu'il y faisait. Le reste ne doit pas être écrit.

Il y avait aussi de l'or, beaucoup d'or, et des bijoux. Lucas l'a compté. Moi, je n'y ai éprouvé aucune joie. C'était le prix de cinquante vies, et je ne sais pas encore ce qu'il convient d'en faire.

## La nuit du crâne vert

Nous sortions à peine. Une rumeur est montée, des cris, des gens qui couraient. La rue baignait dans une lumière verte. J'ai levé les yeux : un crâne immense brûlait dans le ciel, vert comme la marque de ma vision. Puis les explosions sont venues, sur les autres collines, là où se dressent les grands temples.

J'ai pensé aux rats. Aux égouts. À la bibliothèque.

Ma vision commence. Que Lathandre nous garde.

---

*Ainsi s'interrompt ce second fragment, non par choix. Si Lathandre m'accorde l'aube, je le reprendrai. Je ne l'ai pas embelli, et je n'en retrancherai rien.*

*— Isidoro*
